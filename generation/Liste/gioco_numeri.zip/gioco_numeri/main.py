# ====== MENU PRINCIPALE (già pronto — NON modificare) ======
# Raccoglie gli input e chiama la funzione giusta.
# Tu devi solo implementare le funzioni nelle celle sopra.
import time

from utility import stampa_menu
from funzioni import mostra_tutti, gioca

def main():
    #questi dati messi cosi, sono hardcoded, prendiamoli dal file record.txt
    giocatori = {
        "Marco": [("VINTA", 3, 42, 60), ("PERSA", 5, 17, 0), ("VINTA", 1, 88, 100)],
        "Luca": [("VINTA", 4, 7, 40), ("VINTA", 2, 55, 80)],
        "Sara": [("PERSA", 5, 23, 0), ("VINTA", 3, 42, 60)],
    }

    while True:
        stampa_menu()

        scelta = int(input("Scelta: "))

        if scelta == 1:
            mostra_tutti(giocatori)


        elif scelta == 2:
            nick = input("Nickname: ")
            mostra_storico(giocatori, nick)

        elif scelta == 3:
            nick = input("Nickname: ")
            gioca(giocatori, nick)

        elif scelta == 4:
            nick = input("Nickname nuovo giocatore: ")
            aggiungi_giocatore(giocatori, nick)

        elif scelta == 5:
            nick = input("Nickname da rimuovere: ")
            rimuovi_giocatore(giocatori, nick)

        elif scelta == 6:
            nick = input("Nickname: ")
            statistiche(giocatori, nick)

        elif scelta == 7:
            classifica(giocatori)

        elif scelta == 8:
            record_assoluto(giocatori)

        elif scelta == 9:
            numeri_vinti(giocatori)

        elif scelta == 10:
            giocatore_piu_attivo(giocatori)

        elif scelta == 0:
            print("Alla prossima!")
            break

        else:
            print("Scelta non valida.")

        time.sleep(2)


main()