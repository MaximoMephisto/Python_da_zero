# ====== OPERAZIONI DEL MENU (da implementare) ======

# giocatori = {
#     "Marco": [("VINTA", 3, 42, 60), ("PERSA", 5, 17, 0), ("VINTA", 1, 88, 100)],
#     "Luca": [("VINTA", 4, 7, 40), ("VINTA", 2, 55, 80)],
#     "Sara": [("PERSA", 5, 23, 0), ("VINTA", 3, 42, 60)],
# }
def mostra_tutti(giocatori):
    print("I giocatori presenti sono: ")
    for nome in giocatori:
        print(nome)


def mostra_storico(giocatori, nick):
    """[2] Stampa lo storico di un giocatore. Verifica che esista."""
    pass


def gioca(giocatori, nick):
    import random
    num = int(input("Indovina il numero: "))

    num_segreto = random.randint(1,100)

    #questa parte è solo di esempio, cancellarla e applicare logiche inerenti la traccia
    print("num segreto:", num_segreto)
    if num == num_segreto:
        print("hai vinto")
    else:
        print("hai perso")


def aggiungi_giocatore(giocatori, nick):
    """[4] Crea un nuovo giocatore con storico vuoto. Rifiuta nickname duplicati."""
    pass


def rimuovi_giocatore(giocatori, nick):
    """[5] Rimuove un giocatore. Verifica che esista."""
    pass


def statistiche(giocatori, nick):
    """[6] Stampa: partite giocate, vinte, perse, % vittorie (es. '66.7%'),
    punti totali e miglior partita (vittoria col minor numero di tentativi)."""
    pass


def classifica(giocatori):
    """[7] Stampa tutti i giocatori ordinati per punti totali decrescenti."""
    pass


def record_assoluto(giocatori):
    """[8] Trova la vittoria con il MINOR numero di tentativi in assoluto.
    Stampa nickname, numero segreto e tentativi."""
    pass


def numeri_vinti(giocatori):
    """[9] Stampa tutti i numeri segreti INDOVINATI almeno una volta,
    senza duplicati e ordinati. Usa un SET."""
    pass


def giocatore_piu_attivo(giocatori):
    """[10] Stampa il giocatore con lo storico più lungo (più partite)."""
    pass

# ====== MINI-GIOCO (da implementare) ======

def gioca_partita():
    """Gioca una partita a 'Indovina il numero' e RESTITUISCE la tupla:
        (esito, tentativi, numero_segreto, punti)

    Regole:
      - numero segreto = random.randint(1, 100)
      - massimo 5 tentativi
      - dopo ogni errore stampa se il segreto è MAGGIORE o MINORE
      - numeri già provati in un SET: se reinserito, avvisa senza consumare il tentativo
      - punti calcolati con calcola_punti(...)
    """
    pass